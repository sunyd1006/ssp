package com.kuang.demo02;

/**
 * @author ：ltb
 * @date ：2020/7/14
 */
public interface UserService {

    void add();
    void delete();
    void update();
    void query();
}
