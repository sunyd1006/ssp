package com.kuang.demo03;

/**
 * @author ：ltb
 * @date ：2020/7/14
 */
public interface Rent {

    void rent();
}
