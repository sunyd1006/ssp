package com.kuang.pojo;

/**
 * @author ：ltb
 * @date ：2020/7/14
 */
public class Dog {
    public void shout(){
        System.out.println("wang~");
    }

}
