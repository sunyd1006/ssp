package com.kuang.pojo;

/**
 * @author ：ltb
 * @date ：2020/7/14
 */
public class Cat {

    public void shout(){
        System.out.println("miao~");
    }
}
