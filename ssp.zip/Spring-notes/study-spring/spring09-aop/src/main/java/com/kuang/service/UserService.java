package com.kuang.service;

/**
 * @author ：ltb
 * @date ：2020/7/15
 */
public interface UserService {
    void add();
    void delete();
    void update();
    void select();

}
